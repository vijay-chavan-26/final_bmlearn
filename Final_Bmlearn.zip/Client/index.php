<?php include_once('./Components/Header.html') ?>

<?php include_once('./Components/Navbar.php') ?>
<?php include_once('./Components/index.html') ?>   

<?php include_once('./Components/Footer.html') ?>   