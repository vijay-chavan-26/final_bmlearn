<?php include_once('./Components/CheckLoginOrNot.php') ?>
<?php include_once('./Components/Header.html') ?>
<?php include_once('./Components/Navbar.php') ?>

<?php include_once('./Components/videoView.php') ?>
<?php include_once('./Components/Footer.html') ?>
    