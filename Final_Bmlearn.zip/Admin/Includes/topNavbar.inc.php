<nav class="navbar navbar-expand-lg navbar-dark bg-333 fixed-top py-2 w-100">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebar"
            aria-controls="offcanvasExample">
            <span class="navbar-toggler-icon" data-bs-target="#sidebar"></span>
        </button>
        <a class="navbar-brand mx-auto text-uppercase fw-bold" href="index.php">BMLearn</a>
    </div>
</nav>